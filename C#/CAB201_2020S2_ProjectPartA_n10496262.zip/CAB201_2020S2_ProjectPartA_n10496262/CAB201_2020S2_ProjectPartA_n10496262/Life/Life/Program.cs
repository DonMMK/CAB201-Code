﻿using System;
using System.Diagnostics;
using Display;

namespace Life
{
    class Program
    {
        static void Main(string[] args)
        {
            /*******************************************************************
             * Declaring the variables
             ******************************************************************/
            int Rows = 16; //Change back to 16 once testing is over
            int Columns = 16; //Change back to 16 once the testing is over
            bool PeriodicBehaviour = false; //false indicate it will not behave in Periodic manner
            double RandFactor = 0.5;
            string InputFile = "";
            int Generations = 50;
            int MaxUpdateRate = 5; //5 per second
            bool StepMode = false; //Will not be in step mode


            // Construct grid...
            Grid grid = new Grid(Rows, Columns);

            // Wait for user to press a key...
            Console.WriteLine("Press any key to start...");
            Console.ReadKey();

            // Initialize the grid window (this will resize the window and buffer)
            grid.InitializeWindow();

            // Set the footnote (appears in the bottom left of the screen).
            grid.SetFootnote("Life");


            Stopwatch watch = new Stopwatch();


            /*******************************************************************
             * Checking the user input
             ******************************************************************/
           

            /*******************************************************************
             * Game
             ******************************************************************/

            //Game array which stores the cell coordinates
            int[,] GameArray = new int[Rows, Columns];

            //Temporary Array to store the neighbours
            int[,] TempArray = new int[Rows, Columns];

            //To count the number of generations
            int GenCount = 0;

            //Testing the grid with the example given in the specification
            
            int LifePresent = 1;

            GameArray[2, 0] = LifePresent;
            GameArray[1, 1] = LifePresent;
            GameArray[1, 2] = LifePresent;
            GameArray[2, 2] = LifePresent;
            GameArray[3, 2] = LifePresent;
            

            int ThreeCount = 0;

            // For each of the cells...
            for (int i = 0; i < GameArray.GetLength(0); i++)
            {
                for (int j = 0; j < GameArray.GetLength(1); j++)
                {
                    if (GameArray[i, j] == 1)
                    {
                        // Update grid with a new cell...
                        grid.UpdateCell(i, j, CellState.Full);
                    }
                    else
                    {
                        grid.UpdateCell(i, j, CellState.Blank);
                    }
                }
            }

            grid.Render();


            //Increasing the generations
            while (Generations >= GenCount)
            {

                //Checking the neighbours of the cells

                for (int i = 0; i < Rows; i++)
                {
                    for (int j = 0; j < Columns; j++)
                    {
                        ThreeCount = 0;
                        //FOR CENTER
                        if (i > 0 && j > 0 && i < (Rows - 1) && j < (Columns - 1))
                        {
                            ThreeCount += (GameArray[i - 1, j]);

                            ThreeCount += (GameArray[i + 1, j]);

                            ThreeCount += (GameArray[i, j - 1]);

                            ThreeCount += (GameArray[i, j + 1]);

                            ThreeCount += (GameArray[i + 1, j + 1]);

                            ThreeCount += (GameArray[i + 1, j - 1]);

                            ThreeCount += (GameArray[i - 1, j + 1]);

                            ThreeCount += (GameArray[i - 1, j - 1]);
                        }

                        //FOR SIDE (Left Vertical)
                        if ((i > 0) && (i < Rows - 1) && j == 0)
                        {
                            ThreeCount += (GameArray[i - 1, j]);

                            ThreeCount += (GameArray[i + 1, j]);

                            ThreeCount += (GameArray[i, j + 1]);

                            ThreeCount += (GameArray[i + 1, j + 1]);

                            ThreeCount += (GameArray[i - 1, j + 1]);
                        }

                        //FOR SIDE (Top Horizontal)
                        if ((j > 0) && (j < Columns - 1) && i == 0)
                        {
                            ThreeCount += (GameArray[i + 1, j]);

                            ThreeCount += (GameArray[i, j - 1]);

                            ThreeCount += (GameArray[i, j + 1]);

                            ThreeCount += (GameArray[i + 1, j + 1]);

                            ThreeCount += (GameArray[i + 1, j - 1]);
                        }


                        //FOR SIDE (Right Vertical)
                        if ((i > 0) && (i < Rows - 1) && j == Columns - 1)
                        {
                            ThreeCount += (GameArray[i - 1, j]);

                            ThreeCount += (GameArray[i + 1, j]);

                            ThreeCount += (GameArray[i, j - 1]);

                            ThreeCount += (GameArray[i + 1, j - 1]);

                            ThreeCount += (GameArray[i - 1, j - 1]);
                        }

                        //FOR SIDE (Bottom Horizontal)
                        if ((j > 0) && (j < Columns - 1) && i == Rows - 1)
                        {
                            ThreeCount += (GameArray[i - 1, j]);

                            ThreeCount += (GameArray[i, j - 1]);

                            ThreeCount += (GameArray[i, j + 1]);

                            ThreeCount += (GameArray[i - 1, j + 1]);

                            ThreeCount += (GameArray[i - 1, j - 1]);
                        }


                        //FOR EDGE (Top Left)
                        if (i == 0 && j == 0)
                        {
                            ThreeCount += (GameArray[i + 1, j]);

                            ThreeCount += (GameArray[i, j + 1]);

                            ThreeCount += (GameArray[i + 1, j + 1]);

                        }

                        //FOR EDGE (Top Right)
                        if (i == 0 && j == Columns - 1)
                        {
                            ThreeCount += (GameArray[i + 1, j]);

                            ThreeCount += (GameArray[i, j - 1]);

                            ThreeCount += (GameArray[i + 1, j - 1]);
                        }

                        //FOR EDGE (Bottom Left)
                        if (i == Rows - 1 && j == 0)
                        {
                            ThreeCount += (GameArray[i - 1, j]);

                            ThreeCount += (GameArray[i, j + 1]);

                            ThreeCount += (GameArray[i - 1, j + 1]);
                        }

                        //FOR EDGE (Bottom Right)
                        if (i == Rows - 1 && j == Columns - 1)
                        {
                            ThreeCount += (GameArray[i - 1, j]);

                            ThreeCount += (GameArray[i, j - 1]);

                            ThreeCount += (GameArray[i - 1, j - 1]);
                        }

                        //If cell was already alive
                        if (GameArray[i, j] == 1)
                        {
                            //Check if neighbours 2 or 3
                            if (ThreeCount == 2 || ThreeCount == 3)
                            {
                                TempArray[i, j] = 1;
                            }
                        }
                        else
                        {
                            if (ThreeCount == 3)
                            {
                                TempArray[i, j] = 1;
                            }
                        }

                    }
                }



                //Step function holding answer till space is pressed
                if (StepMode == true)
                {
                    while (Console.ReadKey().Key != ConsoleKey.Spacebar) ;
                }


                // For each of the cells...
                for (int i = 0; i < GameArray.GetLength(0); i++)
                {
                    for (int j = 0; j < GameArray.GetLength(1); j++)
                    {
                        if (TempArray[i, j] == 1)
                        {
                            // Update grid with a new cell...
                            grid.UpdateCell(i, j, CellState.Full);
                            GameArray[i, j] = TempArray[i, j];
                        }
                        else
                        {
                            grid.UpdateCell(i, j, CellState.Blank);
                            GameArray[i, j] = 0;

                        }
                        TempArray[i, j] = 0;

                    }
                }
                watch.Restart();
                while (watch.ElapsedMilliseconds < 200) ;
                // Render updates to the console window...
                grid.Render();
                GenCount++;
            }

            // Set complete marker as true
            grid.IsComplete = true;

            // Render updates to the console window (grid should now display COMPLETE)...
            grid.Render();

            // Wait for user to press a key...
            Console.ReadKey();

            // Revert grid window size and buffer to normal
            grid.RevertWindow();



        }
    }
}