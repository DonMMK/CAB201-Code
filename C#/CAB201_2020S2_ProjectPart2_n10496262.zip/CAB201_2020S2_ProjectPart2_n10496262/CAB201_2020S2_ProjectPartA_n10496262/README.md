---
title: Life Project Part 1
author: Don Kaluarachchi n10496262
date: 20/9/2020
---

## Build Instructions

The file was created using Visual studio version 2019. Code was initiallydeveloped for on macOS system but was later copied onto and tested on windows to accomodate for required specifications.
Code can be opened on visual studio and the "Green Play Button" or F5 can be pressed to build the code. This should save all changes done and build the code.

## Usage 

When run using visual studio default conditions will run. To change and use user inputs open up the "Command Prompt" tool. If the user wishes to use visual studio to enter modifications they can follow the following steps,
Debug >> Life properties >> Appication Arguments. 
Else the command prompt can be used and features can be modified such as numbe of generations, the size of the grid, seeds, updates rates etc.


## Notes 

The simulations explores the theory of mathematician John Conway and his creation of "Game of Life". Research was done on his work and code was implemented using the knowledge learned in lecturers and tutorials. 
